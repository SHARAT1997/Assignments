#include"word.h"
int main(){

    Words W;
    string line;
    getline(cin, line);
    W.setWords((char *)line.c_str());
    W.dispWords();

    cout<<"Max of all Words: "<<W.getMaxWord(W.getMaxWords())<<endl;
    cout<<"\n Enter the word to search: "<<endl;
    string key;
    cin>>key;
    cout<<"\nEnter the word to be Replaced: "<<endl;
    string repStr;
    cin>>repStr;
    if(W.SNReplace((char *)key.c_str(),(char *)repStr.c_str())==false)
    {
        cout<<"After Replacing "<<endl;
        W.dispWords();
    }
    return 0;
}
